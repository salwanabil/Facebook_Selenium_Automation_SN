package testcases;

import com.sun.org.glassfish.gmbal.Description;
import org.testng.annotations.Test;
import pages.RegistrationPage;

public class RegistrationTest extends BaseTest {
    RegistrationPage registrationPageObj;
    /*
    tc1 : successful sign up
     */
    @Test(priority = 1, description = "Check that user can sign up successfully")
    public void userCanSignUp_successfully() {
        try {

            registrationPageObj= new RegistrationPage(driver);
            registrationPageObj.enterFirstName("Salwa");
            registrationPageObj.enterLastName("Test");
            registrationPageObj.enterEmail("test858@gmail.com");
            registrationPageObj.enterConfirmEmail("test858@gmail.com");
            registrationPageObj.enterPassword("QN_pp_1234");
            registrationPageObj.selectBirthDate("16", "Dec" , "1985");
            registrationPageObj.selectGender("female");
            registrationPageObj.clickOnSubmitButton();
            Thread.sleep(2000);
        }catch (Exception e)
        {
            e.printStackTrace();
        }
    }
}
