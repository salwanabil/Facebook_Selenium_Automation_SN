package testcases;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.*;
import utilities.Utility;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

public class BaseTest {
    public static WebDriver driver;

    @BeforeClass
    @Parameters({"browser"})
    public void startDriver(@Optional("Chrome")String browserName) throws Exception
    {
        if (browserName.equalsIgnoreCase("chrome"))
        {
            System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir") +"/drivers/chromedriver.exe");

            // Create object of HashMap Class
            Map<String, Object> prefs = new HashMap<String, Object>();

            // Set the notification setting it will override the default setting
            prefs.put("profile.default_content_setting_values.notifications", 2);

            // Create object of ChromeOption class
            ChromeOptions options = new ChromeOptions();

            // Set the experimental option
            options.setExperimentalOption("prefs", prefs);

            // pass the options object in Chrome driver
            driver = new ChromeDriver(options);

            //driver = new ChromeDriver();
        }
        else if (browserName.equalsIgnoreCase("firefox"))
        {
            System.setProperty("webdriver.firefox.marionette",System.getProperty("user.dir") +"/drivers/geckodriver.exe");
            driver = new FirefoxDriver();

        }
		/*else if (browserName.equalsIgnoreCase("firefox")) {
			System.setProperty("webdriver.gecko.driver", System.getProperty("user.dir") +"/drivers/geckodriver.exe");
			driver = new FirefoxDriver();

		}*/ else if (browserName.equalsIgnoreCase("ie")) {
            System.setProperty("webdriver.ie.driver", System.getProperty("user.dir") + "/internetexplorerdriver.exe");
            driver = new InternetExplorerDriver();

        } else {
            System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir") + "/drivers/chromedriver.exe");
            driver = new ChromeDriver();
        }
        //maximize browser view
        driver.manage().window().maximize();
        //driver.manage().timeouts().wait(15);
        driver.get((Utility.fetchPropertyValue("applicationURL").toString()));
    }

   @AfterMethod
    public void closeDriverInstance() {
        driver.quit();
    }

}
