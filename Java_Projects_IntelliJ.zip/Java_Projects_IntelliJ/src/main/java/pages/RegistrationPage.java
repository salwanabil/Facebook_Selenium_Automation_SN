package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class RegistrationPage extends BasePage {
    public RegistrationPage(WebDriver driver){ super(driver);}

    // page elements
    //firstname
    @FindBy(name = "firstname")
    WebElement textFirstName;
    //lastname
    @FindBy(name = "lastname")
    WebElement textLastName;
    //email or phone
    @FindBy(name = "reg_email__")
    WebElement textEmailOrMobile;

    //reconfirm mail
    @FindBy(name = "reg_email_confirmation__")
    WebElement textConfirmMail;

    //password
    @FindBy(name = "reg_passwd__")
    WebElement textPassword;

    //date of birth
    //day dropdown
    @FindBy(xpath = "//select[@title='Day']")
    WebElement selectDay;

    //Month dropdown
    @FindBy(xpath = "//select[@title='Month']")
    WebElement selectMonth;

    //Year dropdown
    @FindBy(name = "birthday_year")
    WebElement selectYear;

    @FindBy(name = "sex")
    WebElement radioFemaleSex;

    @FindBy(name = "websubmit")
    WebElement buttonSubmit;

    /* fill first name field
    @param firstName : is user first name
     */

    public void enterFirstName(String firstName)
    {
        clearAndSetText(textFirstName, firstName);
        KeyPressTab(textFirstName);
    }
    public void enterLastName(String lastName)
    {
        clearAndSetText(textLastName, lastName);
        KeyPressTab(textLastName);
    }
    public void enterEmail(String email)
    {
        waitUntilVisible(textEmailOrMobile);
        clearAndSetText(textEmailOrMobile ,email );
        KeyPressTab(textEmailOrMobile);
    }
    public void enterConfirmEmail(String confirmEmail)
    {
        waitUntilVisible(textConfirmMail);
        clearAndSetText(textConfirmMail, confirmEmail);
        KeyPressTab(textConfirmMail);
    }
    public void enterPassword(String password)
    {
        waitUntilVisible(textPassword);
        clearAndSetText(textPassword, password);
        KeyPressTab(textPassword);
    }

    public void selectBirthDate(String day , String month , String year)
    {
        selectDropDownList(driver, selectDay,day);
        selectDropDownList(driver, selectMonth,month);
        selectDropDownList(driver, selectYear,year);
    }

    public void selectGender(String gender)
    {
        clickButton(radioFemaleSex);
    }

    public void clickOnSubmitButton()
    {
        clickButton(buttonSubmit);
    }

}
