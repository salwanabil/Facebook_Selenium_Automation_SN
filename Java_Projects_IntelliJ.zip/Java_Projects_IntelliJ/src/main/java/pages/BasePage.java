package pages;

import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.awt.*;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.util.ArrayList;
import java.util.List;

public class BasePage {

	protected static WebDriver driver;
	// protected

	public Select select;
	public Actions action;
	public static String currentWindowID = null;
	public static JavascriptExecutor jse;

	// create constructor
	public BasePage(WebDriver driver) {
		PageFactory.initElements(driver, this);
		this.driver = driver;
	}

	// Wait for Next button to be visible.
	public  boolean waitUntilVisible(WebElement element) {

		// Wait for Element to be visible.
		try {
			WebDriverWait wait = new WebDriverWait(driver, 10);
			wait.until(ExpectedConditions.visibilityOf(element));
			// element found, return true
			return true;
		} catch (Exception e) {
			// Element not found, return false
			return false;
		}
	}
	// Wait for Next button to be clickable.
	public boolean waitUntilElementClickableAndClick(WebElement element) {

		// Wait for Element to be visible.
		try {
			WebDriverWait wait = new WebDriverWait(driver, 10);
			element = wait.until(ExpectedConditions.elementToBeClickable(element));
			element.click();
			return true;
		} catch (Exception e) {
			// Element not found, return false
			return false;
		}
	}
	
	// Method to Click Buttons
	protected  void clickButton(WebElement button) {
		button.click();
	}

	// Method to send Keys
	protected  void clearAndSetText(WebElement textElement, String value) {

		waitUntilVisible(textElement);
		textElement.clear();
		textElement.sendKeys(value);
	}

	// Method to send Keys
	protected  void setText(WebElement textElement, String value) {

		waitUntilVisible(textElement);
		textElement.sendKeys(value);
	}

	// Method to Press Enter
	public void KeyPressEnter(WebElement webElement) {

		webElement.sendKeys(Keys.ENTER);
	}

	// Method to Press TAB
	public void KeyPressTab(WebElement webElement) {

		webElement.sendKeys(Keys.TAB);
	}

	// Method to scroll down
	public void scrollToBottom() {

		jse.executeScript("scrollBy(0,1500)");
	}

	public void scrollToTop() {

		jse.executeScript("scrollBy(0,-1500)");
	}

	// Method to confirmCookies
	public void cookieHandle(WebDriver driver) {

		WebElement elementcookie = driver.findElement(By.xpath("//div[@class='cta-button bg-blue']"));
		jse = (JavascriptExecutor) driver;
		jse.executeScript("arguments[0].click();", elementcookie);

	}

	// Method to handle windows
	public void WindowHandling(WebDriver driver) {
		currentWindowID = driver.getWindowHandle();

		for (String windowID : driver.getWindowHandles()) {

			driver.switchTo().window(windowID);
			/*
			 * String URL = driver.getCurrentUrl();
			 * 
			 * if (URL.contains(URL))
			 * 
			 * { }
			 */

		}

	}

	// Method to select from Drop down
	public void selectDropDownList(WebDriver driver, WebElement selectWebElement, String selectItem) {
		Select drop = new Select(selectWebElement);

		drop.selectByVisibleText(selectItem);
	}

	// Method to get text
	public String getText(WebElement e) {
		WebDriverWait wait = new WebDriverWait(driver, 20);
		wait.until(ExpectedConditions.visibilityOf(e));
		return e.getText().toString();
	}

	// Method to swicth driver to the last window
	public void switchDriver() {
		// driver.close();
		ArrayList<String> tabs2 = new ArrayList<String>(driver.getWindowHandles());
		driver.switchTo().window(tabs2.get(tabs2.size() - 1));
	}


	/**
	 * This method will set any parameter string to the system's clipboard.
	 */
	public void setClipboardData(String string) {
		// StringSelection is a class that can be used for copy and paste operations.
		StringSelection stringSelection = new StringSelection(string);
		Toolkit.getDefaultToolkit().getSystemClipboard().setContents(stringSelection, null);
	}
	
	public void refreshPage() {
		driver.navigate().refresh();
	}
	
	public List<WebElement> getListOfChildElements(String xpath) {
	
		List<WebElement> parentEelementList = driver.findElements(By.xpath(xpath));

		return parentEelementList;
		
	}
	
}
